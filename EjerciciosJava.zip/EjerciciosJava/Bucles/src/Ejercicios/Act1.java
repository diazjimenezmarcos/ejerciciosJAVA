package Ejercicios;
import java.util.Scanner;

public class Act1 {
	public static void main(String[] args) {
		int i = 5;
		while (i <=5) {
			System.out.println("Número: " + 5);
			i = i + 1;
		}
	}
}