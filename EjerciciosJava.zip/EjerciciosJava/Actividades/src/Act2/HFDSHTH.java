package Act2;
import java.util.Scanner;

public class HFDSHTH {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int suma,num;
		suma = 0;
		
		System.out.println("Dime un numero: ");
		num = sc.nextInt();
		
		while (num != 0) {
			suma = suma + num;
			System.out.println("Dime otro numero: ");
			num = sc.nextInt();
		}
		
		System.out.println("La suma de los numeros es " + suma);
	}
}
