package com;
import java.util.Scanner;


public class Ejercicio2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Dime un número: ");
		String num = sc.nextLine();
		System.out.println("El numero es: " + num);
		

	}

}
