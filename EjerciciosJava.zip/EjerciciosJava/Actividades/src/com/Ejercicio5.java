package com;

public class Ejercicio5 {
	public static void main(String[] args) {
	short numero = 32767;
	System.out.println("El número antes de incrementar es " + numero);
	numero++;
	System.out.println("El numero es " + numero);
	}
}
