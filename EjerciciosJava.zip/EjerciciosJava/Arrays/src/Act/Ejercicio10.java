package Act;

public class Ejercicio10 {

}
