package Ejercicios;

public class Main {
	public static void main(String[] args) {
		
		Ejemplo.mostrar(5);
		Ejemplo.mostrar("Parpi");
		Ejemplo.mostrar("Parpi", 5);
		
	}
}
