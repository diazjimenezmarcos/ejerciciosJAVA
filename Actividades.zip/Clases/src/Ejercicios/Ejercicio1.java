package Ejercicios;

public class Ejercicio1 {
	private double saldo;
	public double limiteDescubierto;
	private String nombre;
	private String dni;
	
	public Ejercicio1(String dni, String nombre) {
		this.dni = dni;
		this.nombre = nombre;
		this.saldo = 0;
		this.limiteDescubierto = -50.0;
	}
	
	public boolean sacarDinero(double cantidad) throws Exception {
		if(this.saldo - cantidad >= this.limiteDescubierto) {
			this.saldo = this.saldo - cantidad;
			return true;
		}else {
			throw new Exception("No tienes saldo suficiente");
			}
		}
		
	public boolean IngresarDinero(double cantidad) throws Exception {
		if(cantidad > 0) {
			this.saldo += cantidad;
			return true;
		}else {
			throw new Exception("Esa cantidad no es posible");
			}
		}
	
	public String mostrarInformacion(){
		return "DNI: " + this.dni + ",saldo disponible: " + this.saldo;
	}

	public Ejercicio1(double saldo) {
		super();
		this.saldo = saldo;
	}
}
