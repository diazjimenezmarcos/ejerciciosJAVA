package Ejercicios;

public class Ejercicio2 {

}
