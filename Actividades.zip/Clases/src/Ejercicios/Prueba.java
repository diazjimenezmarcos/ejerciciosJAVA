package Ejercicios;

public class Prueba {
	private String nombre;
	private int edad;
	
	public Prueba(String nombre, int edad) {
		this.nombre = nombre;
		this.edad = edad;
}

	public void saluda() {
		
	}

}
