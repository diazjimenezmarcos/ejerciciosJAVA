package DNI;

import java.util.Random;

public class ControladorDNI {
	private final char[] Letras = {'T','R','W','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};
	private final int Divisor = 23;
	private final int LongitudDNI = 8;
	private final int LongitudDNIcompleto = 9;
	

	public char[] getLetras() {
		return Letras;
	}
	
	public String generarAleatorioDNI() {
		return "TODO";
	}
	
	public static void main(String[] args) {
		Random random = new Random();
		int[] DNI = new int[8];
		String Dni = Math.random();
	}
	
}
