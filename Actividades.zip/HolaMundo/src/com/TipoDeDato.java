package com;

public class TipoDeDato {

	public static void main(String[] args) {
		int numero = 100;
		float numero_decimal = 1.1F;
		double numero_decimal2 = 1.1;
		boolean logico = false;
		String palabra = "Tomate";
		char letra = 'd';
		System.out.println("Numero" + 100);
		System.out.println("Numero Decimal: " + numero_decimal);
	}

}
