package Ejercicios;
import java.util.Scanner;

public class multiplo2 {
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Dime un numero: ");
		int num = sc.nextInt();
		int mul = 0;
		
		while (mul <= 10) {
			int tabla = num * mul;
			System.out.println(num + " * " + mul + " = " + tabla);
			mul++;
		}
	}
}
