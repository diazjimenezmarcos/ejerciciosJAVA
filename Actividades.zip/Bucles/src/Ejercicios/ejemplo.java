package Ejercicios;
import java.util.Scanner;

public class ejemplo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = 0;
		int tabla = 0;
		
		while (num<15) {
			tabla = num * 7;
			System.out.println(tabla);
			num++;
		}
	}
}
