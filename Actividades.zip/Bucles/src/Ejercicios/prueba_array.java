package Ejercicios;
import java.util.Scanner;

public class prueba_array {
	public static void main(String[] args) {
		int numeros[] = {1,4,5,10,13,17};
		int num = 3;
		System.out.println(numeros.length);
		System.out.println(numeros[0]);
		for (int i=0; i <= numeros.length-1 ;i++) {
			System.out.println(numeros[i]);
		}
		
		int j = 0;
		while(j<numeros.length) {
			System.out.println(numeros[j]);
			j++;
		}
	}
}
