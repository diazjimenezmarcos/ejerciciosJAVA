package Act;
import java.util.Scanner;

public class Ejercicio8 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Que cantidad de numeros hay en la tabla: ");
		int cantidad = sc.nextInt();
		
		int[] repetidos = new int[cantidad];
		
	}
}
