package Act;
import java.util.Scanner;

public class TresEnRaya {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[][]
	}
}
