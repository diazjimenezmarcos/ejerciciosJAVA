package Act;
import java.util.Scanner;

public class Ejercicio1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		double[] num = new double[5];
		
		for (int i = 0; i < num.length; i++) {
			System.out.println("Dime un  numero decimal: ");
			num[i] = sc.nextDouble();
		}
		
		for (int i = 0 ; i<num.length ; i++) {
			System.out.println(num[i]);
		}
	}
}
